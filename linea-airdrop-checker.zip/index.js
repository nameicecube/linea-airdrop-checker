require('dotenv').config();
const { ethers } = require('ethers');

const LXP_ADDRESS = '0x2d94aa3e47d9d5024503ca8491fce9a2fb4da198';  // Replace with actual LXP token
const LXPL_ADDRESS = '0x6fc8e7031fa8506e5a855103aa16c8c2767c9f97'; // Replace with actual LXP-L token

const ERC20_ABI = [
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
  'function symbol() view returns (string)',
];

async function getTokenBalance(tokenAddress, provider, wallet) {
  const contract = new ethers.Contract(tokenAddress, ERC20_ABI, provider);
  const rawBalance = await contract.balanceOf(wallet);
  const decimals = await contract.decimals();
  const symbol = await contract.symbol();
  const balance = Number(ethers.utils.formatUnits(rawBalance, decimals));
  return { symbol, balance };
}

async function main() {
  const provider = new ethers.providers.JsonRpcProvider(process.env.RPC_URL);
  const wallet = process.env.WALLET_ADDRESS;

  const lxp = await getTokenBalance(LXP_ADDRESS, provider, wallet);
  const lxpl = await getTokenBalance(LXPL_ADDRESS, provider, wallet);

  console.log(`Wallet: ${wallet}`);
  console.log(`${lxp.symbol} Balance: ${lxp.balance}`);
  console.log(`${lxpl.symbol} Balance: ${lxpl.balance}`);

  const estimatedAllocation = (lxp.balance * 1.5) + (lxpl.balance * 2);
  console.log(`Estimated Linea Token Allocation: ~${estimatedAllocation.toFixed(2)} tokens`);
}

main().catch(console.error);
