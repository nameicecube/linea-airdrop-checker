# Linea Airdrop Checker

Check your estimated Linea token allocation based on your LXP and LXP-L balances on Linea Mainnet.

## Features

- Reads wallet balances of LXP and LXP-L
- Calculates estimated Linea token airdrop based on a custom formula
- Simple and fast with ethers.js

## Setup

1. Clone the repo and install dependencies:
   ```bash
   npm install
   ```

2. Create a `.env` file:
   ```env
   RPC_URL=https://rpc.linea.build
   WALLET_ADDRESS=0xYourWalletAddressHere
   ```

3. Run the script:
   ```bash
   node index.js
   ```

## Example Output

```
Wallet: 0xYourWallet
LXP Balance: 1234
LXP-L Balance: 567
Estimated Linea Token Allocation: ~2345.50 tokens
```

## License

MIT
